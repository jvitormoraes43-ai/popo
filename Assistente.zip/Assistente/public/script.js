
const painel = document.getElementById("chatPainel");
const conversa = document.getElementById("conversa");
const formularioInicial = document.getElementById("perguntaInicialForm");
const perguntaInicial = document.getElementById("perguntaInicial");
const formularioMensagem = document.getElementById("formularioMensagem");
const mensagem = document.getElementById("mensagem");
const minimizarChat = document.getElementById("minimizarChat");
const restaurarChat = document.getElementById("restaurarChat");

// Adiciona uma mensagem na tela
function adicionarMensagem(texto, classe) {
  const item = document.createElement("div");
  item.className = `message ${classe}`;
  item.textContent = texto;

  conversa.appendChild(item);
  conversa.scrollTop = conversa.scrollHeight;
}

// Envia a pergunta ao Node.js e recebe a resposta
async function responder(pergunta) {
  adicionarMensagem(pergunta, "user");

  const aviso = document.createElement("div");
  aviso.className = "message assistant";
  aviso.textContent = "Consultando o assistente...";

  conversa.appendChild(aviso);
  conversa.scrollTop = conversa.scrollHeight;

  try {
    const resposta = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        pergunta: pergunta
      })
    });

    const dados = await resposta.json();

    if (!resposta.ok) {
      throw new Error(dados.erro || "Erro na consulta.");
    }

    aviso.textContent = dados.resposta;

  } catch (erro) {
    console.error("Erro:", erro);

    aviso.textContent =
      "Não consegui consultar o assistente agora.";
  }

  conversa.scrollTop = conversa.scrollHeight;
}

// Abre o chat
function abrirChat(pergunta) {
  painel.classList.remove("is-hidden");
  painel.setAttribute("aria-hidden", "false");

  formularioInicial.classList.add("is-hidden");
  restaurarChat.classList.add("is-hidden");

  if (pergunta) {
    responder(pergunta);
  }

  mensagem.focus();
}

// Envia a primeira pergunta
formularioInicial.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const pergunta = perguntaInicial.value.trim();
  if (!pergunta) return;

  perguntaInicial.value = "";
  abrirChat(pergunta);
});

// Envia mensagens dentro do chat
formularioMensagem.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const pergunta = mensagem.value.trim();
  if (!pergunta) return;

  mensagem.value = "";
  responder(pergunta);
});

// Minimiza o chat
minimizarChat.addEventListener("click", () => {
  painel.classList.add("is-hidden");
  painel.setAttribute("aria-hidden", "true");

  formularioInicial.classList.remove("is-hidden");
  restaurarChat.classList.remove("is-hidden");
});

// Restaura o chat
restaurarChat.addEventListener("click", () => {
  abrirChat();
});
