
const painel = document.getElementById("chatPainel");
const conversa = document.getElementById("conversa");
const formularioInicial = document.getElementById("perguntaInicialForm");
const perguntaInicial = document.getElementById("perguntaInicial");
const formularioMensagem = document.getElementById("formularioMensagem");
const mensagem = document.getElementById("mensagem");
const minimizarChat = document.getElementById("minimizarChat");
const restaurarChat = document.getElementById("restaurarChat");

const historicoConversa = [];

  let conversaId = localStorage.getItem("sic_conversa_atual");

  if (!conversaId) {
    conversaId = crypto.randomUUID();
    localStorage.setItem("sic_conversa_atual", conversaId);
  }

// Adiciona uma mensagem na tela
function adicionarMensagem(texto, classe) {
  const item = document.createElement("div");
  item.className = `message ${classe}`;
  item.textContent = texto;

  conversa.appendChild(item);
  conversa.scrollTop = conversa.scrollHeight;
}

// Envia a pergunta ao Node.js e recebe a resposta
async function responder(pergunta) {
  adicionarMensagem(pergunta, "user");

  const aviso = document.createElement("div");
  aviso.className = "message assistant";
  aviso.textContent = "Consultando o assistente...";

  conversa.appendChild(aviso);
  conversa.scrollTop = conversa.scrollHeight;

  try {
    const resposta = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        pergunta,
        historico: historicoConversa,
        conversaId
      })
    });

    const dados = await resposta.json();

    if (!resposta.ok) {
      throw new Error(
        dados.erro || "Erro ao consultar o assistente."
      );
    }

    // Mostra a resposta do Gemini no chat
    aviso.textContent = dados.resposta;

    // Salva a pergunta e a resposta no histórico
    historicoConversa.push({
      role: "user",
      texto: pergunta
    });

    historicoConversa.push({
      role: "model",
      texto: dados.resposta
    });

    // Mantém somente as últimas 10 mensagens
    if (historicoConversa.length > 10) {
      historicoConversa.splice(
        0,
        historicoConversa.length - 10
      );
    }

  } catch (erro) {
    console.error("Erro no chat:", erro);
    aviso.textContent =
      "Desculpe, não consegui consultar o assistente agora.";
  }

  conversa.scrollTop = conversa.scrollHeight;
}

async function carregarConversaAnterior() {
  try {
    const resposta = await fetch(
      `/api/atendimentos/${conversaId}`
    );

    if (resposta.status === 404) {
      return;
    }

    if (!resposta.ok) {
      throw new Error("Erro ao recuperar atendimento.");
    }

    const dados = await resposta.json();

    if (!Array.isArray(dados.mensagens)) {
      return;
    }

    // Limpa as mensagens exibidas anteriormente
    conversa.innerHTML = "";

    // Limpa o histórico usado pelo Gemini
    historicoConversa.length = 0;

    // Recupera todas as mensagens na tela
    for (const item of dados.mensagens) {
      if (
        !["user", "model"].includes(item.role) ||
        typeof item.texto !== "string"
      ) {
        continue;
      }

      adicionarMensagem(
        item.texto,
        item.role === "user" ? "user" : "assistant"
      );

      historicoConversa.push({
        role: item.role,
        texto: item.texto
      });
    }

    // Mantém as últimas 10 mensagens para o Gemini
    if (historicoConversa.length > 10) {
      historicoConversa.splice(
        0,
        historicoConversa.length - 10
      );
    }

  } catch (erro) {
    console.error("Erro ao carregar conversa:", erro);
  }
}


// Abre o chat
function abrirChat(pergunta) {
  painel.classList.remove("is-hidden");
  painel.setAttribute("aria-hidden", "false");

  formularioInicial.classList.add("is-hidden");
  restaurarChat.classList.add("is-hidden");

  if (pergunta) {
    responder(pergunta);
  }

  mensagem.focus();
}

// Envia a primeira pergunta
formularioInicial.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const pergunta = perguntaInicial.value.trim();
  if (!pergunta) return;

  perguntaInicial.value = "";
  abrirChat(pergunta);
});

// Envia mensagens dentro do chat
formularioMensagem.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const pergunta = mensagem.value.trim();
  if (!pergunta) return;

  mensagem.value = "";
  responder(pergunta);
});

// Minimiza o chat
minimizarChat.addEventListener("click", () => {
  painel.classList.add("is-hidden");
  painel.setAttribute("aria-hidden", "true");

  formularioInicial.classList.remove("is-hidden");
  restaurarChat.classList.remove("is-hidden");
});

// Restaura o chat
restaurarChat.addEventListener("click", () => {
  abrirChat();
});

carregarConversaAnterior();